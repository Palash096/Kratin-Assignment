//import axios from 'axios';
import { useState } from 'react';
import { Link, useHistory, useParams } from 'react-router-dom';
import { useEffect } from 'react/cjs/react.development';
import customerService from '../../services/customer.service';
import '../../css/customerList.css';

const AddCustomer = () => {
  const [customerName, setCutomerName] = useState('');
  const [customerMobile, setcustomerMobile] = useState('');
  const [customerAddr, setcustomerAddress] = useState('');
  const [customerAge, setCustomerAge] = useState('');
  const [disease, setdisease] = useState('');
  const [food, setfood] = useState('');
  const [sleephours, setsleephours] = useState('');
  const [bodyWeight, setbodyWeight] = useState('');
  const [height, setheight] = useState('');
  const [waterIntake, setwaterIntake] = useState('');
  const [activity, setactivity] = useState('');

  const history = useHistory();
  const { id } = useParams();

  const saveCustomer = (e) => {
    e.preventDefault();

    const customer = {
      customerName,
      customerMobile,
      customerAddr,
      customerAge,
      activity,
      disease,
      food,
      sleephours,
      bodyWeight,
      height,
      waterIntake,
      id,
    };
    if (id) {
      //update
      customerService
        .update(customer)
        .then((response) => {
          console.log('Customer data updated successfully', response.data);
          history.push('/customer');
        })
        .catch((error) => {
          alert(error.response.status);
          console.log('Error code ' + error);
          console.log('Something went wrong', error.response.data);
        });
    } else {
      //create
      customerService
        .create(customer)
        .then((response) => {
          console.log('Customer added successfully', response.data);
          history.push('/customer');
        })
        .catch((error) => {
          console.log('something went wroing' + error.response);
        });
    }
  };

  useEffect(() => {
    if (id) {
      customerService
        .get(id)
        .then((customer) => {
          setCutomerName(customer.data.customerName);
          setcustomerMobile(customer.data.customerMobile);
          setcustomerAddress(customer.data.customerAddr);
          setCustomerAge(customer.data.customerAge);
          setdisease(customer.data.disease);
          setfood(customer.data.food);
          setsleephours(customer.data.sleephours);
          setbodyWeight(customer.data.bodyWeight);
          setheight(customer.data.height);
          setwaterIntake(customer.data.waterIntake);
          setactivity(customer.data.activity);
        })
        .catch((error) => {
          console.log('Something went wrong', error);
        });
    }
  }, []);
  return (
    <div className='customerDiv'>
      <div className='container'>
        <h3>Fill Your Details</h3>
        <hr />
        <form>
          <div className='form-group'>
            <input
              type='text'
              className='form-control col-4'
              id='cname'
              value={customerName}
              onChange={(e) => setCutomerName(e.target.value)}
              placeholder='Enter Customer Name'
            />
          </div>
          <div className='form-group'>
            <input
              type='number'
              className='form-control col-4'
              id='customerMobile'
              value={customerMobile}
              onChange={(e) => setcustomerMobile(e.target.value)}
              placeholder='Enter Mobile Number'
            />
          </div>
          <div className='form-group'>
            <input
              type='text'
              className='form-control col-4'
              id='customerAddr'
              value={customerAddr}
              onChange={(e) => setcustomerAddress(e.target.value)}
              placeholder='Enter Address'
            />
          </div>
          <div className='form-group'>
            <input
              type='number'
              className='form-control col-4'
              id='customerAge'
              value={customerAge}
              onChange={(e) => setCustomerAge(e.target.value)}
              placeholder='Enter Age'
            />
          </div>
          <div className='form-group'>
            <input
              type='text'
              className='form-control col-4'
              id='disease'
              value={disease}
              onChange={(e) => setdisease(e.target.value)}
              placeholder='Enter Disease (If Any)'
            />
          </div>
          <div className='form-group'>
            <input
              type='text'
              className='form-control col-4'
              id='food'
              value={food}
              onChange={(e) => setfood(e.target.value)}
              placeholder='Enter Food Intake per day'
            />
          </div>
          <div className='form-group'>
            <input
              type='number'
              className='form-control col-4'
              id='sleephours'
              value={sleephours}
              onChange={(e) => setsleephours(e.target.value)}
              placeholder='Enter Sleep Hours'
            />
          </div>
          <div className='form-group'>
            <input
              type='number'
              className='form-control col-4'
              id='bodyWeight'
              value={bodyWeight}
              onChange={(e) => setbodyWeight(e.target.value)}
              placeholder='Enter Body Weigth'
            />
          </div>
          <div className='form-group'>
            <input
              type='number'
              className='form-control col-4'
              id='height'
              value={height}
              onChange={(e) => setheight(e.target.value)}
              placeholder='Enter Height'
            />
          </div>
          <div className='form-group'>
            <input
              type='number'
              className='form-control col-4'
              id='waterIntake'
              value={waterIntake}
              onChange={(e) => setwaterIntake(e.target.value)}
              placeholder='Enter Water intake per day'
            />
          </div>
          <div className='form-group'>
            <input
              type='text'
              className='form-control col-4'
              id='activity'
              value={activity}
              onChange={(e) => setactivity(e.target.value)}
              placeholder='Activity (Yes/No)'
            />
          </div>
          <div>
            <button onClick={(e) => saveCustomer(e)} className='btn btn-primary'>
              Submit Details
            </button>
          </div>
        </form>
        <hr />
        <Link to='/customer'>Go to Customer DashBoard</Link>
      </div>
    </div>
  );
};

export default AddCustomer;
