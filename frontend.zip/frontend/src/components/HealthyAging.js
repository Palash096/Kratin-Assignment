import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import '../css/healthCare.css';


const HealthyAging = () => {


  return (
    <div className='employeeDiv'>
      <div className='container'>
        <h1 id='top'>What Do We Know About Healthy Aging?</h1>
        <hr />
        <div id="main">
          <p>
            Many factors influence healthy aging. Some of these, such as genetics, are not in our control. Others — like exercise, a healthy diet, going to the doctor regularly, and taking care of our mental health — are within our reach. Research supported by NIA and others has identified actions you can take to help manage your health, live as independently as possible, and maintain your quality of life as you age. Read on to learn more about the research and the steps you can take to promote healthy aging.
          </p>

          <h3>On this page</h3>
          <h5>
            <a href='#link1'>1. Taking care of your physical health</a>
            <br />
            <a href='#link2'>2. Healthy eating: Make smart food choices</a>
            <br />
            <a href='#link3'>3. Getting a good night’s sleep</a>
            <br />
            <a href='#link4'>4. Quit smoking</a>
            <br />
            <a href='#link5'>5. Alcohol and other substances</a>
            <br />
            <a href='#link6'>6. Go to the doctor regularly</a>
            <br />
            <a href='#link7'>7. Taking care of your mental health</a>
            <br />
            <a href='#link8'>8. Stress</a>
            <br />
            <a href='#link9'>9. Depression and overall mood</a>
            <br />
            <a href='#link10'>10. Leisure activities and hobbies</a>
            <br />
            <a href='#link11'>11. Taking care of your cognitive health</a>
            <br />
            <a href='#link12'>12. Taking care of your cognitive health</a>
          </h5>
          <br />
          
          <h2>1. Taking care of your physical health</h2>
          <section>
            While scientists continue to actively research how to slow or prevent age-related declines in physical health, they’ve already discovered multiple ways to improve the chances of maintaining optimal health later in life. Taking care of your physical health involves staying active, making healthy food choices, getting enough sleep, limiting your alcohol intake, and proactively managing your health care. Small changes in each of these areas can go a long way to support healthy aging.<br/>
            <br/>

            
            Get moving: Exercise and physical activity
            Whether you love it or hate it, physical activity is a cornerstone of healthy aging. Scientific evidence suggests that people who exercise regularly not only live longer, but also may live better — meaning they enjoy more years of life without pain or disability.Older adult, in a park, doing yoga on a mat.<br/><br/>

            A study of adults 40 and older found that taking 8,000 steps or more per day, compared to only taking 4,000 steps, was associated with a 51% lower risk of death from all causes. You can increase the number of steps you get each day by doing activities that keep your body moving, such as gardening, walking the dog, and taking the stairs instead of the elevator.<br/><br/>

            Although it has many other benefits, exercise is an essential tool for maintaining a healthy weight. Adults with obesity have an increased risk of death, disability, and many diseases such as type 2 diabetes and high blood pressure. However, thinner is not always healthier either. Being or becoming too thin as an older adult can weaken your immune system, increase the risk of bone fracture, and in some cases may be a symptom of disease. Both obesity and underweight conditions can lead to loss of muscle mass, which may cause a person to feel weak and easily worn out.<br/><br/>

            As people age, muscle function often declines. Older adults may not have the energy to do everyday activities and can lose their independence. However, exercise can help older adults maintain muscle mass as they age. In a 2019 investigation of data from NIA’s Baltimore Longitudinal Study of Aging, researchers found that moderate to vigorous physical activity is strongly associated with muscle function, regardless of age. This suggests that exercise may be able to prevent age-related decline in muscle function.<br/><br/>

            In addition to helping older adults live better, maintaining muscle mass can help them live longer. In another study, researchers found that in adults older than 55, muscle mass was a better predictor of longevity than was weight or body mass index (BMI).<br/><br/>

            <b>What can you do?</b><br/>
            Although many studies focus on the effects of physical activity on weight and BMI, research has found that even if you’re not losing weight, exercise can still help you live longer and better. There are many ways to get started. Try being physically active in short spurts throughout the day or setting aside specific times each week to exercise. Many activities, such as brisk walking or yoga, are free or low cost and do not require special equipment. As you become more active, you will start feeling energized and refreshed after exercising instead of exhausted. The key is to find ways to get motivated and get moving.<br/><br/>




          </section>
          <br />
          <section id='link2'>
            <h2>2. Healthy eating: Make smart food choices</h2>
            <p>Making smart food choices can help protect you from certain health problems as you age and may even help improve brain function. As with exercise, eating well is not just about your weight. With so many different diets out there, choosing what to eat can be confusing. The 2020-2025 Dietary Guidelines for Americans provide healthy eating recommendations for each stage of life. The Dietary Guidelines suggest an eating pattern with lots of fresh fruits and vegetables, whole grains, healthy fats, and lean proteins.dinner plate on a table with salmon and veggies.<br/><br/>

              Much of the research shows that the Mediterranean-style eating pattern, which includes fresh produce, whole grains, and healthy fats, but less dairy and more fish than a traditional American diet, may have a positive impact on health. A 2021 study analyzing the eating patterns of more than 21,000 participants found that people closely following the Mediterranean-style pattern had a significantly lower risk of sudden cardiac death.<br/><br/>

              A low-salt diet called Dietary Approaches to Stop Hypertension (DASH) has also been shown to deliver significant health benefits. Studies testing the DASH diet found that it lowers blood pressure, helps people lose weight, and reduces the risk of type 2 diabetes and heart disease.<br/><br/>

              Yet another eating pattern that may support healthy aging is the MIND diet, which combines a Mediterranean-style eating pattern with DASH. Researchers have found that people who closely follow the MIND diet have better overall cognition — the ability to clearly think, learn, and remember — compared to those with other eating styles.<br/><br/>

              <b>What can you do?</b><br/>
              Try starting with small changes by adopting one or two aspects of the Mediterranean-style eating pattern or MIND diet. Several studies have shown that incorporating even a part of these eating patterns, such as more fish or more leafy greens, into your daily eating habits can improve health outcomes. One study of 182 older adults with frequent migraines found that a diet lower in vegetable oil and higher in fatty fish could reduce migraine headaches. Another study that followed almost 1,000 older adults over five years found that consumption of green leafy vegetables was significantly associated with slower cognitive decline.<br/><br/>

              Even if you haven’t thought much about healthy eating until recently, changing your diet now can still improve your well-being as an older adult. If you are concerned about what you eat, talk with your doctor about ways you can make better food choices.<br/><br/>

              Learn more about healthy eating and smart food choices for healthy aging.<br/><br/>

            </p>
          </section>
          <section id='link3'>
            <h2>3. Getting a good night’s sleep</h2>
            <p>
              Getting enough sleep helps you stay healthy and alert. Even though older adults need the same seven to nine hours of sleep as all adults, they often don’t get enough. Feeling sick or being in pain can make it harder to sleep, and some medicines can keep you awake. Not getting enough quality sleep can make a person irritable, depressed, forgetful, and more likely to have falls or other accidents.older adult sleeping in a bed.<br/><br/>

              Sleep quality matters for memory and mood. In one study of adults older than 65, researchers found that those who had poor sleep quality had a harder time problem-solving and concentrating than those who got good quality sleep. Another study, which looked at data from nearly 8,000 people, showed that those in their 50s and 60s who got six hours of sleep or less a night were at a higher risk of developing dementia later in life. This may be because inadequate sleep is associated with the buildup of beta-amyloid, a protein involved in Alzheimer’s disease. Poor sleep may also worsen depression symptoms in older adults. Emerging evidence suggests that older adults who were diagnosed with depression in the past, and do not get quality sleep, may be more likely to experience their depression symptoms again.<br/><br/>

              More generally, a 2021 study found that older adults who did not sleep well and napped often were at greater risk of dying within the next five years. Conversely, getting good sleep is associated with lower rates of insulin resistance, heart disease, and obesity. Sleep can also improve your creativity and decision-making skills, and even your blood sugar levels.<br/><br/>

              <b>What can you do?</b><br/>
              There are many things you can do to help you sleep better, such as following a regular sleep schedule. Try to fall asleep and get up at the same time each day. Avoid napping late in the day, as this may keep you awake at night. Exercise can help you sleep better, too, if it isn’t too close to bedtime. Research suggests that behavioral interventions, such as mindfulness meditation, can also improve sleep quality.<br/><br/>

              Learn more about how to get a good night’s sleep and check out this infographic.<br/><br/>
            </p>
          </section>
          <section id='link4'>
            <h2>4. Quit smoking</h2>
            <p>
              It doesn’t matter how old you are or how long you’ve been smoking, research confirms that even if you’re 60 or older and have been smoking for decades, quitting will improve your health. Quitting smoking at any age will:<br/><br/>

              Lower your risk of cancer, heart attack, stroke, and lung disease<br/>
              Improve your blood circulation<br/>
              Improve your sense of taste and smell<br/>
              Increase your ability to exercise<br/>
              Set a healthy example for others<br/>
              One study found that among men 55 to 74 years old and women 60 to 74 years old, current smokers were three times more likely to die within the six-year follow-up period than those who had never smoked.<br/><br/>

              <b>What can you do?</b><br/>
              If you smoke, quit. Quitting smoking is good for your health and may add years to your life. One study of nearly 200,000 people demonstrated that older adults who quit smoking between the ages of 45 and 54 lived about six years longer compared to those who continued to smoke. Adults who quit between the ages of 55 to 64 lived about four years longer. It is never too late to stop smoking and reap the benefits of breathing easier, having more energy, saving money, and improving your health.<br/><br/>

              Read more about how to quit smoking as an older adult.<br/><br/>
            </p>
          </section>
          <section id='link5'>
            <h2>5. Alcohol and other substances</h2>
            <p>
              Like all adults, older adults should avoid or limit alcohol consumption. In fact, aging can lead to social and physical changes that make older adults more susceptible to alcohol misuse and abuse and more vulnerable to the consequences of alcohol. Alcohol dependence or heavy drinking affects every organ in the body, including the brain.<br/><br/>

              A comprehensive study from the National Institute on Alcohol Abuse and Alcoholism shows that alcohol consumption among older adults, especially women, is on the rise. The researchers also found evidence that certain brain regions show signs of premature aging in alcohol-dependent men and women. In addition, heavy drinking for extended periods of time in older adults may contribute to poor heart health, as shown in this 2016 study. These studies suggest that stopping or limiting the use of alcohol could improve heart health and prevent the accelerated aging seen with heavy alcohol use.<br/><br/>

              In addition to being cautious with alcohol, older adults and their caregivers should be aware of other substances that can be misused or abused. Because older adults are commonly prescribed opioids for pain and benzodiazepines for anxiety or trouble sleeping, they may be at risk for misuse and dependence on these substances. One study of adults age 50 and older showed that misuse of prescription opioids or benzodiazepines is associated with thoughts of suicide.<br/><br/>

              <b>What can you do?</b><br/>
              Learn about the current U.S. guidelines for drinking and when to avoid alcohol altogether. It’s important to be aware of how much you are drinking and the harm that drinking can cause. If you or a loved one needs help with substance abuse or alcohol use, talk with your doctor or a mental health professional. You can also try finding a support group for older adults with substance or alcohol abuse issues.<br/><br/>

              Learn about substance use in older adults and get tips on how to stop drinking alcohol or drink less alcohol.<br/><br/>
            </p>
          </section>
          <section id='link6'>
            <h2>6. Go to the doctor regularly</h2>
            <p>
              Going to the doctor for regular health screenings is essential for healthy aging. A 2021 study found that getting regular check-ups helps doctors catch chronic diseases early and can help patients reduce risk factors for disease, such as high blood pressure and cholesterol levels. People who went to the doctor regularly also reported improved quality of life and feelings of wellness.Older adult reviewing information with his doctor.<br/><br/>

              In recent years, scientists have developed and improved upon laboratory, imaging, and similar biological tests that help uncover and monitor signs of age-related disease. Harmful changes in the cells and molecules of your body may occur years before you start to experience any symptoms of disease. Tests that detect these changes can help medical professionals diagnose and treat disease early, improving health outcomes.<br/><br/>

              <b>What can you do?</b><br/>
              Visit the doctor at least yearly and possibly more depending on your health. You cannot reap the benefits of medical advancements without regular trips to the doctor for physical exams and other tests. Regular screenings can uncover diseases and conditions you may not yet be aware of, such as diabetes, cancer, and cardiovascular disease. If you only seek medical attention when you’re experiencing symptoms, you may lose the chance of having your doctor catch a disease in its earliest stages, when it would be most treatable. Regular check-ups can help ensure you could start treatment months or years earlier than would have been possible otherwise.<br/><br/>

              Read about how you can make the most of your appointment with your doctor.<br/><br/>
            </p>
          </section>
          <section id='link7'>
            <h2>7. Taking care of your mental health</h2>
            <p>
              Mental health, or mental wellness, is essential to your overall health and quality of life. It affects how we think, feel, act, make choices, and relate to others. Managing social isolation, loneliness, stress, depression, and mood through medical and self-care is key to healthy aging.<br/><br/>

              Social isolation and loneliness<br/>
              As people age, changes such as hearing and vision loss, memory loss, disability, trouble getting around, and the loss of family and friends can make it difficult to maintain social connections. This makes older adults more likely to be socially isolated or to feel lonely. Although they sound similar, social isolation and loneliness are different. Loneliness is the distressing feeling of being alone or separated, while social isolation is the lack of social contacts and having few people to interact with regularly.Older woman, appearing sad, looking out a window.<br/><br/>

              Several recent studies show that older adults who are socially isolated or feel lonely are at higher risk for heart disease, depression, and cognitive decline. A 2021 study of more than 11,000 adults older than age 70 found that loneliness was associated with a greater risk of heart disease. Another recent study found that socially isolated older adults experienced more chronic lung conditions and depressive symptoms compared to older adults with social support.<br/><br/>

              Feeling lonely can also impact memory. A study of more than 8,000 adults older than 65 found that loneliness was linked to faster cognitive decline.<br/><br/>

              Research also shows that being socially active can benefit older adults. A study of more than 3,000 older adults found that making new social contacts was associated with improved self-reported physical and psychological well-being. Being social may also help you reach your exercise goals. A 2019 study found that older adults who had regular contact with friends and family were more physically active than those who did not.<br/><br/>

              <b>What can you do?</b><br/>
              Staying connected with others may help boost your mood and improve your overall well-being. Stay in touch with family and friends in person or over the phone. Scheduling time each day to connect with others can help you maintain connections. Meet new people by taking a class to learn something new or hone a skill you already have.<br/><br/>

              Learn about loneliness and social isolation and get tips for how to stay Connected.<br/><br/>
            </p>
          </section>
          <section id='link8'>
            <h2>8. Stress</h2>
            <p>
              Stress is a natural part of life and comes in many forms. Sometimes stress arises from difficult events or circumstances. Positive changes, like the birth of a grandchild or a promotion, can cause stress too. Research shows that constant stress can change the brain, affect memory, and increase the risk of developing Alzheimer’s or related dementias.<br/><br/>

              Older adults are at particular risk for stress and stress-related problems. A recent study examined how levels of the stress hormone cortisol change over time. Researchers have found that cortisol levels in a person’s body increase steadily after middle-age, and that this age-related increase in stress may drive changes in the brain. A meta-analysis funded by the National Institute of Mental Health supports the notion that stress and anxiety rewire the brain in ways that can impact memory, decision-making, and mood.<br/><br/>

              Finding ways to lower stress and increase emotional stability may support healthy aging. In an analysis of data from the Baltimore Longitudinal Study of Aging, scientists followed 2,000 participants for more than five decades, monitoring their mood and health. The data reveal that individuals who were emotionally stable lived on average three years longer than those who had a tendency toward being in a negative or anxious emotional state. Long-term stress also may contribute to or worsen a range of health problems, including digestive disorders, headaches, and sleep disorders.<br/><br/>

              <b>What can you do?</b><br/>
              You can help manage stress with meditation techniques, physical activity, and by participating in activities you enjoy. Keeping a journal may also help you identify and challenge negative and unhelpful thoughts. Reach out to friends and family who can help you cope in a positive way.

              Read about more ways to manage stress.<br/><br/>
            </p>
          </section>
          <section id='link9'>
            <h2>9. Depression and overall mood</h2>
            <p>
              Although depression is common in older adults, it can be difficult to recognize. For some older adults with depression, sadness is not their main symptom. Instead, they might feel numb or uninterested in activities and may not be as willing to talk about their feelings. Depression not only affects mental health, but also physical health. A review article funded by the National Heart, Lung, and Blood Institute summarizes hundreds of studies from around the world showing that depression increases risk of heart disease and metabolic disorders. Research has also shown that recurrent depression is a risk factor for dementia. In a study of more than 1,000 older adults, scientists found a relationship between the number of depressive episodes and increased risk of developing Alzheimer’s.Older adult holding his head in his hands, looking sad.<br/><br/>

              Although different than depression, which is a serious medical disorder, mood changes can also influence aging. A 2020 longitudinal study demonstrated a link between positive mood and better cognitive control. Further studies are necessary to determine whether changes that improve mood could improve cognition. The way you think about aging can also make a difference. Research shows that whether you hold negative or positive views about aging may impact health as you age. Negative beliefs about aging may increase undesirable health outcomes, Alzheimer’s disease biomarkers, and cellular aging. Meanwhile, positive beliefs about aging may decrease the risk of developing dementia and obesity.<br/><br/>

              <b>What can you do?</b><br/>
              Depression, even when severe, can be treated. As soon as you begin noticing signs, it’s important to get evaluated by a health care professional. In addition to deep sadness or numbness, lack of sleep and loss of appetite are also common symptoms of depression in older adults. If you think you or a loved one may have depression, start by making an appointment to see your doctor or health care provider. If you are thinking of harming yourself, get help immediately — call the 24-hour 988 Suicide & Crisis Lifeline at 988 or 800-273-TALK (800-273-8255).<br/><br/>


            </p>
          </section>
          <section id='link10'>
            <h2>10. Leisure activities and hobbies</h2>
            <p>
              Your favorite activities are not only fun — they may also be good for your health. Research shows that people who participate in hobbies and social and leisure activities may be at lower risk for some health problems. For example, one study found that participation in a community choir program for older adults reduced loneliness and increased interest in life. Another study showed that older adults who spent at least an hour reading or engaged in other hobbies had a decreased risk of dementia compared to those who spent less than 30 minutes a day on hobbies.Grandmother playing a game with her granddaughter.<br/><br/>

              Research on music, theater, dance, creative writing, and other participatory arts shows promise for improving older adults’ quality of life and well-being, from better cognitive function, memory, and self-esteem to reduced stress and increased social interaction. Even hobbies as simple as taking care of a pet can improve your health. According to a 2020 study, pet ownership (or regular contact with pets) was associated with better cognitive function, and in some cases, better physical function.<br/><br/>

              <b>What can you do?</b><br/>
              Look for opportunities to participate in activities. Get out and about by going to a sporting event, trying a new restaurant, or visiting a museum. Learn how to cook or play a musical instrument. Consider volunteering at a school, library, or hospital to become more active in your community.<br/><br/>

              Learn more about participating in activities you enjoy.<br/><br/>
            </p>
          </section>
          <section id='link11'>
            <h2>11. Taking care of your cognitive health</h2>
            <p>
              Cognition — the ability to clearly think, learn, and remember — often changes as we age. Although some people develop Alzheimer’s or other types of dementia, many older adults experience more modest changes in memory and thinking. Research shows that healthy eating, staying active, and learning new skills may help keep older adults cognitively healthy.<br/><br/>

              How different factors affect cognitive health
              If you think your daily choices don’t make a difference, data from an NIH study with 3,000 participants show otherwise. Researchers scored participants on five healthy lifestyle factors, all of which have important health benefits:<br/><br/>

              At least 150 minutes per week of moderate- to vigorous-intensity physical activity<br/>
              Not smoking<br/>
              Not drinking heavily<br/>
              A high-quality, Mediterranean-style diet<br/>
              Engagement in mentally stimulating activities, such as reading, writing letters, and playing games
              The findings show that making these small, daily changes can add up to significant health benefits. Those who followed at least four of these healthy lifestyle behaviors had a 60% lower risk of developing Alzheimer’s. Even practicing just two or three activities lowered the risk by 37%. While results from observational studies such as this one cannot prove cause and effect, they point to how a combination of modifiable behaviors may mitigate Alzheimer's risk and identify promising avenues to be tested in clinical trials.<br/><br/>

              New clinical trials are also testing the benefits of tightly controlling blood pressure on healthy aging. These trials are based on a 2019 study, with data supporting the idea that intensive blood pressure control may slow age-related brain damage and even mild cognitive impairment, which can increase the risk for Alzheimer’s or a related dementia.<br/><br/>

              Researchers continue work to understand how we might prevent Alzheimer’s and other forms of age-related cognitive decline. NIA is currently funding more than 350 active clinical trials on Alzheimer’s and related dementias, 100 of which use nondrug interventions, such as exercise, diet, cognitive training, sleep, or combination therapies.<br/><br/>

              Read about what we know about preventing Alzheimer’s disease.<br/><br/>
            </p>
          </section>
          <section id='link12'>
            <h2>12. Taking care of your cognitive health</h2>
            <p>
              Many brain training programs are marketed to the public to improve cognition. Although some of these computer or smartphone-based interventions show promise, so far there is no conclusive evidence that these applications are beneficial.Older man playing the guitar while his wife listens.<br/><br/>

              But there is some evidence that exercising your brain by learning a new skill can improve memory function. A study of adults 60 and older showed that sustained engagement in cognitively demanding, novel activity enhanced memory function. In particular, the new skills learned in this study were <br/>1) learning how to use computer software to edit photos and <br/>2) learning how to quilt. Learning a new game, instrument, craft, or other skill can be fun and may have the added benefit of staving off memory loss as you age.<br/><br/>

              Learn more about cognitive health.<br/><br/>
            </p>
          </section>
          <section >
            <h2>Next steps</h2>
            <p>
              Next steps<br/>
              Infographic, Tips To boost Your Health As You Age. Click link for full infographic
              Read and share this infographic and spread the word about ways that may help foster healthy aging.
              Taking care of your physical, mental, and cognitive health is important for healthy aging. Even making small changes in your daily life can help you live longer and better. In general, you can support your physical health by staying active, eating and sleeping well, and going to the doctor regularly. Take care of your mental health by interacting with family and friends, trying to stay positive, and participating in activities you enjoy. Taking steps to achieve better physical and mental health may reduce your risk for Alzheimer’s and related dementias as you age.<br/><br/>

              There is still a lot to learn, though, about how people age and what habits support healthy aging. Scientists are exploring these questions with studies that look at physical, mental, and cognitive health. You can be a part of scientific progress by joining a clinical trial or research study in person or online. All types of volunteers are needed, including caregivers, older adults with medical conditions, and those who are healthy.<br/><br/>
            </p>
            <div align="right"> <a href='#top'>Go to top</a></div>

          </section>
        </div>
        <div>
          <Link to='/customer'>Back to Dash Board</Link>
        </div>
      </div>
    </div>

  );
};

export default HealthyAging;
