import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import '../css/healthCare.css';


const HealthyTips = () => {
  return (
    <div className='employeeDiv'>
      <div className='container'>
        <h1 id="top">Healthy Aging Tips for the Older Adults in Your Life</h1>
        <hr />
        <p>
          If you have older family members or loved ones, you may worry about their health as they age. Aging increases the risk of chronic diseases such as heart disease, type 2 diabetes, arthritis, cancer, and dementia. The good news is that adopting and maintaining a few key behaviors can help older adults live longer, healthier lives. As a family member, it’s important to encourage healthy lifestyle behaviors in your loved ones — it’s never too late to start!
        </p>
        <p>
          Healthy behavior changes can help older adults live more independently later in life. That’s important both for their quality of life and for yours. If a family member loses independence — whether it’s due to disability or chronic disease — you may find yourself in a caregiving role earlier than expected, which can affect family dynamics as well as finances.
        </p>
        <p>
          So what can you do to help the older adults in your life manage their health, live as independently as possible, and maintain quality of life as they age? Read on to learn about four ways to help support and promote healthy habits in your older loved ones’ lives.
        </p>
        <div>
          <h3>On this page</h3>
          <h4>
            <a href='#link1'>1. Prevent social isolation and loneliness</a>
            <br />
            <a href='#link2'>2. Promote physical activity</a>
            <br />
            <a href='#link3'>3. Encourage healthy eating</a>
            <br />
            <a href='#link4'>4. Schedule regular check-ups with a doctor</a>
            <br />
          </h4>
          <br />
          <section>
            Nutrition needs vary with age and gender. Now you’re older, the foods and drinks that make up a healthy diet may need to be slightly different from when you were younger. In general, you’ll need less of some foods and more of others.
            <br /><br />
            How you eat as an older person will also vary depending on your gender: older men have different nutritional needs from older women.
            <br /><br />
            But healthy eating doesn’t really change that much with age, especially if you already have a good diet. You simply need to be aware of your own specific nutrition requirements and adjust your food choices so your body gets exactly what it needs for good health in older age.
            <br /><br />
            If you need help choosing or preparing a healthy diet, chat to a family member, your healthcare professional, carer or an Accredited Practising Dietitian.
            <br />
            Discuss any major change in eating or exercise patterns with your doctor, pharmacist and dietitian. Any medications you take may need to be adjusted.
          </section>
          <br />
          <h2>1. Prevent social isolation and loneliness</h2>
          <section>
            As people age, they often find themselves spending more time alone. Poor health, the death of a partner, caring for a loved one, and other situations that are more likely as people age can all lead to being socially isolated or feeling lonely.
            <br /><br />
            Although they sound similar, social isolation and loneliness are different. Loneliness is the distressing feeling of being alone or separated, while social isolation is the lack of social contacts and having few people to interact with regularly. Increased social isolation and loneliness are associated with higher risks for health problems, such as depression; heart disease; and cognitive decline, which is a decrease in the ability to think, learn, and remember.
            <br /><br />
            As a family member, you can play an important role in helping the older adults in your life to stay socially connected. Here are some ways you can help:
            <br /><br />
            &diams; Schedule daily, weekly, or biweekly phone calls or video chats.
            <br /><br />
            &diams; Encourage them to seek out others with shared interests, such as through a garden club, volunteer organization, or walking group.
            <br /><br />
            &diams; Search the Eldercare Locator or call 800-677-1116. The Eldercare Locator is a nationwide service that connects older adults and their caregivers with trustworthy local support resources.
            <br /><br />
            Find additional tips to help your loved one stay socially connected.
            <br />
          </section>
          <br />
          <section id='link2'>
            <h2>2. Promote physical activity</h2>
            <br />
            <p>There are lots of reasons to make physical activity a part of daily life. Exercise can help reduce levels of stress and anxiety, improve balance and lower risk of falls, enhance sleep, and decrease feelings of depression. Most importantly, people who exercise regularly not only live longer, but also may live better — meaning they enjoy more years of life with less pain or disability. On the other hand, lack of physical activity can lead to increased visits to the doctor, more hospitalizations, and increased risk of certain chronic conditions.
              <br /><br />
              &diams; Help your loved ones aim for a mix of activities, including aerobics, strength training, balance, and flexibility. This could include walking around the neighborhood, lifting weights, gardening, or stretching.
              <br /><br />
              &diams; Discuss how much activity is recommended and brainstorm ways to work it into their daily lives. Experts recommend at least 150 minutes per week of moderate-intensity aerobic exercise, and muscle-strengthening activities at least two days each week.
              <br /><br />
              &diams; Help them shop for appropriate clothing and equipment for their exercise activities. Remember, many activities don’t require expensive equipment. For example, they can use filled water bottles as weights for strength training or walk outside or at a mall rather than on a treadmill.
              <br /><br />
              &diams; Share your favorite activities that get you moving. Are there any you could do together? If so, that’s a bonus because you’re not only helping promote physical activity but also helping to prevent loneliness and social isolation.
              <br /><br />
              Learn more about the different types of exercises and find examples to help get started.</p>
          </section>
          <br />
          <section id='link3'>
            <h2>3. Encourage healthy eating</h2>
            <br />
            <p>
              Healthy eating is an important part of healthy aging. As with exercise, eating well is not just about weight. Having a healthy diet can help support muscles and strengthen bones, which can help with balance and independence. A nutritious diet involving a variety of fresh fruits and vegetables, whole grains, healthy fats, and lean proteins also can help boost immunity and lower the risk of certain health problems such as heart disease, high blood pressure, obesity, type 2 diabetes, stroke, and some cancers.
              <br /><br />
              While it can be meaningful to share meals based on traditional family recipes, in some cases, those favorite dishes can be loaded with unhealthy fats and sugars. Changing long-held habits can be tough, but before you know it, there may be some new favorite foods on the table! Consider these tips to help incorporate a healthy diet in your loved ones’ routines:
              <br /><br />
              &diams; Take them on a trip to the grocery store and pick out healthy options.
              <br /><br />
              &diams; Discuss their favorite traditional recipes and talk about whether you can make them healthier; for example, by substituting olive oil for butter, or yogurt for sour cream.
              <br /><br />
              &diams; Visit them once a week and make a healthy meal together. Consider cooking extra and packaging leftovers so they have individual servings to enjoy later in the week.
              <br /><br />
              &diams; Look inside their fridge and pantry when you visit. You can check for healthy options, and also ensure they aren’t eating expired food or drinks.
              <br /><br />
              &diams; Encourage them to talk with their doctor or pharmacist about their diet and any vitamin and mineral supplements they may need.
              <br /><br />
              Learn more about healthy eating patterns and ways to create a nutritious meal plan.
            </p>
          </section>
          <br />
          <section id='link4'>
            <h2>4. Schedule regular check-ups with a doctor</h2>
            <br />
            <p>
              It’s important for your older loved ones to have regular health exams and medical screenings. Visit MedlinePlus to learn about health screenings for women and men. Checking in with doctors annually, and possibly more often, depending on overall health, may help reduce risk factors for disease such as high blood pressure and cholesterol levels. Regular check-ups can also help catch concerns early and improve the chances for effective treatment.
              <br /><br />
              Some people visit their doctors routinely, while others avoid these types of appointments at all costs. Here are some ways to support your family members’ visits with health care providers:
              <br /><br />
              &diams; Encourage them to reach out to their doctor immediately if they’re experiencing pain or any new symptoms.
              <br /><br />
              &diams; Ask about their upcoming visits to doctors, including any specialists. Do they have the appropriate appointments scheduled and marked on a calendar? Do they need any help scheduling appointments?
              <br /><br />
              &diams; Offer to drive them to the appointment, or even go with them and take notes.
              <br /><br />
              &diams; Ask about communication with their health care providers. Are the doctors responsive to their questions?
              <br /><br />
              &diams; Help them manage medications if needed. Make sure they maintain a current list of their medications, including both prescription and over-the-counter medications and any supplements, and are sharing this list with their health care providers.
              <br /><br />
              &diams; Ask your older family member if they’d feel comfortable allowing you or another family member access to their medical records and permission to talk with their doctors. This could help them stay on top of their appointments and medications.
              <br /><br />
              <h4>How can I encourage healthy behaviors from afar?</h4>
              <br />
              Even if you don’t live close to your parents or other aging family members, you can still help promote healthy habits in their lives. Schedule phone calls to check in and ask about their daily meals, how active they are, and if they’re taking their medications properly. After your discussion, if needed, you can gently talk with them about ways to incorporate healthier approaches. If your family member uses video technology for visits with health care professionals, you could join them to help take notes and ask questions. If you can’t visit your loved ones frequently, ask a trusted family member or friend who is close by to check in on them.
              <br /><br />
              Behavior changes can be difficult and take time. If you’re committed to helping your older loved ones adopt healthier lifestyles, try to be patient. If something isn’t working right away, stick with it or try a different approach. Your support and encouragement can make a difference!
            </p>
          </section>
          <br />
          
          <div align="right"> <a href='#top'>Go to top</a></div>

        </div>
        <div>
          <Link to='/customer'>Back to Dash Board</Link>
        </div>
      </div>
    </div>

  );
};

export default HealthyTips;
