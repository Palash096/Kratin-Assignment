import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import '../css/healthCare.css';


const HappyAndHealthyLIfe = () => {
    return (
        <div className='employeeDiv'>
            <div className='container'>
                <h1 id='top'>Ways to Live a Happy and Healthy Life During Old Age</h1>
                <hr />
                <div id="main">
                    <p>
                        With various medical complications progressing with age, it’s fascinating to encounter healthy older people who are still robust enough to carry out heavy work. But more than physical health, older adults live happy lives when they are mentally and socially fit.<br/><br/>

                        To ensure the best of your senior years, you need to eat healthily, get enough sleep and exercise, build good relationships, and engage in recreational activities and community service.<br/><br/>

                        In this article, we talk about how health declines with old age and the simple ways you can do to reclaim your wellness and happiness.<br/>
                        <br></br>

                    </p>
                    <h3>Table of Contents</h3>
                    <h5>
                        <a href='#link1'>1. What Age Does Health Decline?</a>
                        <br />
                        <a href='#link2'>2. Ways to Live a Happy and Healthy Life During Old Age</a>
                        <br />
                        <a href='#link3'>3. Bottomline</a>
                        <br />
                    </h5>
                    <br />

                    <h2>1.  What Age Does Health Decline?</h2>
                    <section>
                        Your physical health begins to drastically downgrade by the time you turn 50 years old.<br/><br/>

                        In a research study made from 2012 to 2014, researchers studied 775 participants aged 30 to 100 to measure their strength, endurance, and balance. For example, those in their 50s had difficulty standing on one leg and rising from a chair. Meanwhile, those in their 60s and 70s had lost endurance and walking speed.<br/><br/>

                        <b>Factors for Elderly Health Decline</b><br/><br/>

                        The World Health Organization explained that aging results from the accumulation of a wide variety of molecular and cellular damage over time. When we age, there’s a gradual decrease in physical and mental health and an increasing threat of disease as well as death. The age to be considered elderly is 65. However, most elderly need geriatric expertise or care at 70 to 80.<br/><br/>

                        <b>Common Illnesses and Conditions Associated With Aging</b><br/>
                        The most common illnesses linked to old age are:
                        <ul>
                        <li>cataracts and refractive errors</li>
                        <li>hearing loss</li>
                        <li>back and neck pain</li>
                        <li>osteoarthritis</li>
                        <li>chronic obstructive pulmonary disease</li>
                        <li>diabetes</li>
                        <li>depression</li>
                        <li>dementia</li>
                        </ul>
                        Older people are more likely to experience several conditions at the same time due to the body’s decline in physical and mental capacity. Moreover, geriatric syndromes or several complex health states result from various underlying factors like frailty, urinary incontinence, falls, delirium, and pressure ulcers.<br/>
                        <br /><br />
                    </section>
                    <br />
                    <section id='link2'>
                        <h2>2. Ways to Live a Happy and Healthy Life During Old Age</h2>
                        <p><b>Have a Healthy Diet</b><br></br>
                            <u>Eating well prevents health problems</u> like heart disease, stroke, diabetes, and obesity. Foods that are healthy to consume when growing old should contain enough carbohydrates, protein, fats, vitamins, and minerals. Here are some of the food diets to consider based on NIA:<br/><br/>
                            <ul>
                            <li>Vegetable varieties like dark leafy greens such as spinach, red-orange vegetables like carrots, and beans or peas</li>
                            <li>Fruits such as raspberries, apples, or blueberries. 
                            It is better to choose fresh fruits if possible</li>
                            <li>Whole grains such as whole wheat, oats, or brown rice</li>
                            <li>Proteins like fish, lean meat, poultry, eggs, nuts, beans, quinoa, or soy products</li>
                            <li>Low-fat dairy, low-fat milk, cheese, yogurt; soy, rice, and almonds are good alternatives if you are lactose intolerant</li>
                            Plant oils like grapeseed or olive oil</ul>
                            <u>Staying hydrated</u> is also crucial because your sense of thirst weakens as you age.<br/><br/>

                            Also, avoid consuming foods that are high in:<br/><br/>
                            <ul>
                            <li><b>Added sugars:</b> Consuming too many calories can lead to various age-related diseases. Also, the AHA sugar recommendation for men is not to consume nine teaspoons of added sugar a day, and women should not consume six teaspoons daily.</li><br/><br/>
                            <li><b>Trans and Saturated fats:</b> Consuming too much of these fats can clog your arteries, leading to heart disease or attack. With that, reduce saturated fat consumption in meat, cream, or butter. Plant-based fats are better alternatives.</li><br/><br/>
                            <li><b>Sodium:</b> Consuming too much salt, more than 2,300 milligrams of sodium, or a teaspoon daily, is dangerous to your health.</li></ul><br/><br/>
                            <b>Practice Healthy Physical Activities</b><br></br>
                            Research shows that regular physical activity is safe for the healthy and frail elderly. Also, the risk of developing major cardiovascular and metabolic diseases, obesity, falls, cognitive impairments, osteoporosis, and muscular weaknesses are reduced by regularly doing activities from light to vigorous physical activities.<br/><br/>

                            According to the CDC, adults aged 65 and older need at least 30 minutes a day, five days a week, or 150 minutes a week of moderate-intensity activity like brisk walking; or a 75-minute vigorous-intensity exercise like jogging, hiking, or running.<br/><br/>

                            Even a 15-minute walk increases longevity for the elderly. Plus, it is a good alternative for those who cannot do intense activities. Furthermore, good senior health can be maintained with exercises that strengthen the muscles twice a week and three days a week to improve balance, like standing on one leg.<br/><br/>

                            <b>Get Enough Sleep</b><br/><br/>
                            Sleep is crucial in health and aging. However, our body clock changes when we get older. As a result, many elderly experience insomnia or do not get enough sleep. Consequently, this can increase the risk of several health conditions and chronic diseases such as diabetes, cardiovascular disease, obesity, and depression. Poor sleep can also be a sign of ill health or biological aging.<br/><br/>

                            Research shows that older adults diagnosed with more chronic medical conditions like high blood pressure, diabetes, chronic lung disease, heart attack, stroke, cancer, and arthritis have more depressive symptoms.<br/><br/>

                            Also, people with chronic insomnia show a sign of the onset of depression. BMJ stated that better self-reported sleep is linked to better health outcomes. Therefore, sleep is vital for the elderly mental and physical health and should not be taken for granted.<br/><br/>

                            <b>Have Healthy Relationships</b><br/><br/>
                            Spending time and maintaining a healthy, loving relationship with your loved ones, significantly when growing old, can help you cope with stress or problems, improve cognitive functions, and better elderly mental health and cardiovascular health.<br/><br/>

                            An article published in the National Library of Medicine shows that family relationships play an essential role in our well-being throughout our lives, regardless of age.<br/><br/>

                            What’s more, researchers found that feeling loved or having brief experiences of love and connection daily have shown significantly higher levels of psychological well-being. As a result, people who feel loved have a more heightened sense of purpose and optimism than those who think the opposite.<br/><br/>

                           <b>Do Your Hobbies or Interests</b><br></br>
                            Having hobbies or pursuing the things that interest and make you happy during old age can improve senior health. That being said, a study shows that engagement in leisure activities can reduce the probability of experiencing depression in old age.<br/><br/>

                            An article published in NCBI suggests that having hobbies and purpose in life can improve healthy life expectancy, especially for those community-dwelling older adults.<br/><br/>

                            <b>Do Community Service</b><br></br>
                            Volunteering is a suggested activity for older people. In a study, researchers stated that having healthy older adults means lower health complications and expenses. So they can make valuable contributions to society.<br/><br/>

                            For instance, men who engage in activities related to social awareness experience positive life satisfaction. Meanwhile, women who engage in activities related to religious issues experience more positive life satisfaction. Therefore, researchers concluded that engaging in volunteering makes a strong positive impact on life and senior health.<br/><br/>
                        </p>
                    </section>
                    <section id='link3'>
                        <h2>3. Bottomline</h2>
                        <p>
                            Aging is part of our life cycle. And as we age, our mental and physical health declines, potentially leading to geriatric syndromes or health complications like diabetes, heart diseases, and osteoarthritis. Some of which are brought about by bad habits.<br/><br/>

                            For this reason, it is crucial to live healthily and consciously. We can lessen these health issues by having a healthy diet, staying active, and doing things that make you feel good to live happily and healthily. Thus, to live and experience life longer is a privilege deprived. Embrace the gift.<br/><br/>
                        </p>
                    </section>
                   
                </div>
                <div align="right"> <a href='#top'>Go to top</a></div>
                <div>
                    <Link to='/customer'>Back to Dash Board</Link>
                </div>
            </div>
        </div>

    );
};

export default HappyAndHealthyLIfe;
